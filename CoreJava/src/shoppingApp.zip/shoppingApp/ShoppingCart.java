package shoppingApp;

public class ShoppingCart implements ShoopingInterface{
	
	private Product[] items;
	private double total;
	private int itemsCount;
	
	public ShoppingCart() {
		items = new Product[5];
		itemsCount = 0;
		total = 0;
	}
	
	public void addToCart(Product p) throws CartSizeException{
		if(itemsCount < 5) {
			
			this.items[itemsCount] = p;
			total += p.getPrice();
			itemsCount++;
			System.out.println("Product added to cart");
			
		}
		else {
			
			throw new CartSizeException("Cart is full!");
			
		}
	}
	
	public void checkout() {
		if(itemsCount != 0) {			
			System.out.println("=============================");
			System.out.println("Your cart detials ->");
			
			for(Product p: items) {
				if(p != null) {					
					System.out.println(p);
				}
			}
			
			System.out.println("=============================");
			System.out.println("Total : "+this.total);
			
		}
		else {
			System.out.println("Cart is empty!");
		}
	}
	
}
