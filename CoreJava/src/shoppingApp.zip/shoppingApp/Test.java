package shoppingApp;

public class Test {

	public static void main(String[] args) {
		
		ShoopingInterface s = CartFactory.getCart();
		s.checkout();
		
		try {
			
			s.addToCart(new Product("Facewash",150));
			s.addToCart(new Product("HandWash",100));
			s.addToCart(new Product("Facewash",150));
			s.addToCart(new Product("HandWash",100));
			s.addToCart(new Product("Facewash",150));
			s.addToCart(new Product("HandWash",100));
			
		} catch (CartSizeException e) {
			e.printStackTrace();
		}
		
		s.checkout();
	}
	
}
